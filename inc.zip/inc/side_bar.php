
<div class="grid_2">
    <div class="box sidemenu">
        <div class="block" id="section-menu"  style="height:auto; width:auto;">
            <ul class="section menu">
               <li><a class="menuitem">Issue/Return</a>
                    <ul class="submenu">
                        <li><a href="issuebook">Issue Book</a></li>
                        <li><a href="issuedlist">Return Book</a></li>                        
                    </ul>
                </li>                
               <li><a class="menuitem">Student</a>
                    <ul class="submenu">
                        <li><a href="studentadd">Reg Student</a></li>
                        <li><a href="studentlist">All Student</a></li>
                        
                    </ul>
                </li>
                 <li><a class="menuitem">Book</a>
                    <ul class="submenu">
                        <li><a href="bookadd">Add Book</a></li>
                        <li><a href="booklist">View Book</a></li>
                    </ul>
                </li>				
                 <li><a class="menuitem">Category</a>
                    <ul class="submenu">
                        <li><a href="catadd">Add Category</a></li>
                        <li><a href="catlist">View Category</a></li>
                    </ul>
                </li>
                <li><a class="menuitem">Author</a>
                    <ul class="submenu">
                        <li><a href="authoradd">Add Author</a> </li>
                        <li><a href="authorlist">View Author</a> </li>
                    </ul>
                </li>
                <li><a class="menuitem">Publisher</a>
                    <ul class="submenu">
                        <li><a href="publisheradd">Add Publisher</a> </li>
                        <li><a href="publisherlist">View Publisher</a> </li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</div>