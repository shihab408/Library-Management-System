        <div class="clear">
        </div>
    </div>
    <div class="clear">
    </div>
    <div id="site_info" style="text-align:center;">
        <p>
         &copy; Copyright <a href="www.mpi.edu.bd">Mymensingh polytechnic Institute</a>. All Rights Reserved.
        </p>
    </div>
</body>
</html>